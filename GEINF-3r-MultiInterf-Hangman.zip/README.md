# HANGMAN
The main goal of the implementation has been to create a webpage as close as possible to the original reference.

> Note that the "log in" frame is hidden and the game frame is shown once the user presses enter or hits "Start Game", using only one webpage and javascript.

Once the first goal has been reached, our efforts have been devoted to making the game playable with only the keyboard so hardcore players can win as fast as possible.

> By Aniol Juanola (u1978893) & Jordi Badia (u1978902)